<?php
$sortBy = isset($_COOKIE['sort_by']) ? $_COOKIE['sort_by'] : 'tanggal';
$sortOrder = isset($_COOKIE['sort_order']) ? $_COOKIE['sort_order'] : 'asc';

$data_transaksi = [];
if (isset($_COOKIE['transaksi']) && $_COOKIE['transaksi'] != "") {
    $baris = explode("|", $_COOKIE['transaksi']);
    foreach ($baris as $item) {
        $kolom = explode("#", $item);
        if (isset($kolom[0]) && isset($kolom[1])) {
            $data_transaksi[$kolom[0]] = $kolom[1];
        }
    }

    if ($sortBy == 'tanggal') {
        ($sortOrder == 'asc') ? ksort($data_transaksi) : krsort($data_transaksi);
    } else {
        ($sortOrder == 'asc') ? asort($data_transaksi) : arsort($data_transaksi);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Project WEBPROG</title>
</head>
<body>
    <p>
        <a href="tambah.php">[Tambah Transaksi]</a> 
        <a href="setting.php">[Setting]</a>
    </p>

    <?php if (empty($data_transaksi)): ?>
        <p>Belum ada Data</p>
    <?php else: ?>
        <ul>
            <?php foreach ($data_transaksi as $tgl => $nom): ?>
                <li><?php echo $tgl . " - Rp. " . number_format($nom); ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>