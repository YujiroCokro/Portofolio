<?php
$notif = "";
if (isset($_POST['btnSimpan'])) {
    $tgl_baru = $_POST['txtTanggal'];
    $nom_baru = $_POST['txtNominal'];

    $string_data = isset($_COOKIE['transaksi']) ? $_COOKIE['transaksi'] : "";
    
    $data_array = [];
    if ($string_data != "") {
        $baris = explode("|", $string_data);
        foreach ($baris as $item) {
            $kolom = explode("#", $item);
            if (isset($kolom[0]) && isset($kolom[1])) {
                $data_array[$kolom[0]] = $kolom[1];
            }
        }
    }

    $data_array[$tgl_baru] = $nom_baru;

    $temp = [];
    foreach ($data_array as $tgl => $nom) {
        $temp[] = $tgl . "#" . $nom;
    }
    $string_final = implode("|", $temp);

    setcookie('transaksi', $string_final, time() + (86400 * 30), "/");
    
    header("Location: tambah.php?sukses=1");
    exit();
}
if (isset($_GET['sukses'])) { $notif = "Data berhasil ditambah"; }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Transaksi</title>
    <style>
        label { display: inline-block; width: 80px; }
    </style>
</head>
<body>
    <h3>Tambah Transaksi</h3>
    <p style="color: green;"><?php echo $notif; ?></p>
    <form method="post" action="tambah.php">
        <p>
            <label>Tanggal</label>
            <input type="date" name="txtTanggal" required>
        </p>
        <p>
            <label>Nominal</label>
            <input type="number" name="txtNominal" required>
        </p>
        <p>
            <input type="submit" name="btnSimpan" value="Simpan">
        </p>
    </form>
    <br>
    <a href="index.php"><<< Kembali</a>
</body>
</html>