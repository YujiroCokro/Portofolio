<?php
$notif = "";
if (isset($_POST['btnSimpanSetting'])) {
    setcookie('sort_by', $_POST['radioSort'], time() + (86400 * 30), "/");
    setcookie('sort_order', $_POST['radioOrder'], time() + (86400 * 30), "/");
    header("Location: setting.php?sukses=1");
    exit();
}
if (isset($_GET['sukses'])) { $notif = "Data berhasil disimpan"; }

$currSort = isset($_COOKIE['sort_by']) ? $_COOKIE['sort_by'] : 'tanggal';
$currOrder = isset($_COOKIE['sort_order']) ? $_COOKIE['sort_order'] : 'asc';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Setting</title>
</head>
<body>
    <h3>Setting</h3>
    <p style="color: green;"><?php echo $notif; ?></p>
    <form method="post" action="setting.php">
        <p>
            Urut Berdasarkan: 
            <input type="radio" name="radioSort" value="tanggal" <?php if($currSort=='tanggal') echo 'checked'; ?>> Tanggal
            <input type="radio" name="radioSort" value="nominal" <?php if($currSort=='nominal') echo 'checked'; ?>> Nominal
        </p>
        <p>
            Arah: 
            <input type="radio" name="radioOrder" value="asc" <?php if($currOrder=='asc') echo 'checked'; ?>> Ascending
            <input type="radio" name="radioOrder" value="desc" <?php if($currOrder=='desc') echo 'checked'; ?>> Descending
        </p>
        <p>
            <input type="submit" name="btnSimpanSetting" value="Simpan">
        </p>
    </form>
    <br>
    <a href="index.php"><<< Kembali</a>
</body>
</html>